# MCP SDK v2 migration — implementation record

Target: `@modelcontextprotocol/server` 2.4.0 + `@modelcontextprotocol/node` 2.1.2 (the adapter has its own release cadence).

## Implemented in source 0.4.0

The official codemod was not executed because npm registry DNS is unavailable in this environment. The v1-to-v2 edits were applied manually against the official migration guide and reviewed against the current API reference. No `@mcp-codemod-error` markers are present because no codemod output was generated.

- Replaced v1 `StreamableHTTPServerTransport` per-request wiring with v2 `createMcpHandler`.
- Added `toNodeHandler` adapter for the existing plain `node:http` edge.
- Uses `legacy: 'stateless'` so one factory serves 2026-07-28 modern requests and stateless 2025-era clients.
- Applies request-body limits in both the SDK handler and Node adapter, before MCP dispatch.
- Converted all seven tool registrations to `registerTool` with explicit Zod v4 object schemas.
- Preserved Bearer authentication, Origin/Host allowlists, JSON content-type validation, SQLite persistence, and health endpoint.
- Added handler shutdown to graceful termination.

## Verification still required

This environment cannot resolve `registry.npmjs.org` (`EAI_AGAIN` on 2026-10-31), and no package cache contains the v2 dependencies. Consequently the following remain unverified: package installation/integrity, TypeScript compilation, runtime import/export resolution, MCP protocol conformance, Node adapter integration, client end-to-end tests, and container build. Do not describe this migration as build-verified or production-ready until those gates pass.

## Official API contracts consulted

- `createMcpHandler` creates per-request MCP server instances and supports `legacy: 'stateless'`, `maxRequestBodySize`, `onerror`, and `close()`.
- `toNodeHandler(handler, { maxRequestBodySize, onerror })` adapts Node HTTP streams and enforces a bounded body.
- v2 tool registration uses `registerTool(name, { description, inputSchema: z.object(...) }, handler)`.

References: https://ts.sdk.modelcontextprotocol.io/v2/migration/upgrade-to-v2 ; https://ts.sdk.modelcontextprotocol.io/v2/migration/support-2026-07-28 ; https://ts.sdk.modelcontextprotocol.io/v2/api/@modelcontextprotocol/server/server/createMcpHandler.html ; https://ts.sdk.modelcontextprotocol.io/v2/api/@modelcontextprotocol/node/toNodeHandler.html
