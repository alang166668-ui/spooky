# Autonomous Workbench MCP Core 0.4.0

Cloud-ready, stateless Streamable HTTP MCP server on MCP TypeScript SDK v2.4.0 (modern 2026-07-28 protocol plus legacy stateless compatibility), with Bearer-token authentication and SQLite-backed task/checkpoint/event persistence. The same tool surface is served at `POST /mcp`; `GET /healthz` is a minimal unauthenticated liveness/readiness probe.

## Protocol compatibility

This 0.4.0 source targets `@modelcontextprotocol/server` v2.4.0 and `@modelcontextprotocol/node` v2.1.2 (independent package version lines). It serves modern 2026-07-28 requests and legacy stateless 2025-era requests. The migration is implemented in source but remains unverified until dependencies install, typecheck/build, protocol E2E, and container tests pass. See [`MCP_V2_MIGRATION_PLAN.md`](./MCP_V2_MIGRATION_PLAN.md).

## MCP tools

- `workbench_identity` (stable internal identity; optional Registry refs are reported as unverified until externally checked)
- `workbench_health`
- `task_create`, `task_list`, `task_get`, `task_update`
- `task_checkpoint`, `task_event`

## Cloud deployment requirements

- Node.js 20+ (Docker image uses Node 22)
- HTTPS termination at the hosting platform / reverse proxy
- A persistent writable volume mounted at `/data` (SQLite WAL database)
- `NODE_ENV=production`
- `AW_BEARER_TOKEN` with at least 32 characters, injected as a secret
- Optional `AW_ALLOWED_HOSTS` and `AW_ALLOWED_ORIGINS` comma-separated allowlists for the public hostname and browser origins
- Public MCP endpoint: `https://YOUR_HOST/mcp`

Do not deploy with ephemeral filesystem storage: task history will be lost when the instance is replaced. For multi-instance horizontal scaling, replace SQLite with PostgreSQL before enabling multiple replicas; SQLite is intended for one active instance with a persistent volume.

## Docker deployment

```bash
cp .env.example .env
# Replace AW_BEARER_TOKEN with a unique random secret
# Then:
docker compose up -d --build
curl -fsS http://localhost:8080/healthz
```

Configure the MCP client using Streamable HTTP and the exact deployed endpoint. Supply `Authorization: Bearer <secret>` through the client's supported secret/header configuration. Never put the token in a URL, source file, plugin manifest, or chat message.

## Local development

```bash
npm run install:resilient
npm run build
npm test
npm start
```

`install:resilient` checks DNS before invoking npm. The default registry is `https://registry.npmjs.org/`. If the operator has independently approved an HTTPS mirror, it can be supplied through `AW_NPM_REGISTRY` or the comma-separated `AW_NPM_REGISTRY_FALLBACKS`. The installer never silently switches to an unverified mirror; if all configured registry hosts fail DNS, it stops early and reports the failing hosts. npm's HTTP retry settings help with transient HTTP errors but cannot repair DNS/network egress failures.

Set `AW_DB_PATH` to control the SQLite file. In non-production development, an unset token allows local requests without authentication; production startup refuses to run without a strong token.

## Identity and Registry boundary

The core has a stable local identity by default: `autonomous-workbench` / `workbench.orchestration` / `0.4.0`. These values are internal identifiers only; they are **not** Neura Registry Agent Passport or capability-version refs. The optional environment variables `NEURA_REGISTRY_AGENT_REF` and `NEURA_REGISTRY_CAPABILITY_VERSION_REF` must be supplied together. If present, the service reports `refs_configured_unverified`; it never claims they are valid until a Registry/Relay lookup confirms them. Registry registration is not required for core task persistence or local MCP operation.

`workbench_identity` exposes only non-secret identity metadata and boolean ref-presence flags. It never returns credentials or private evidence. Neura Registry supplies identity context; Neura Relay independently reviews proposed actions. A Registry standing is not execution permission, and a Relay decision does not itself execute downstream work.

## Security and current boundaries

- MCP endpoint accepts authenticated JSON POST requests only; no unauthenticated tool calls. Requests carrying an `Origin` header are rejected unless the origin is explicitly allowlisted; host allowlisting can also be enabled.
- Health endpoint returns only service/version status.
- Stateless HTTP transport: no server-side MCP session state.
- SQLite transactions protect multi-write task/checkpoint operations; WAL and foreign keys are enabled.
- All callers sharing this single bearer token share one task namespace; this is not multi-tenant isolation.
- This service stores task state; it does not execute arbitrary shell commands, browse the web, run plugin actions, or schedule background jobs.
- Run one replica with persistent storage. Back up `/data` regularly. For multi-replica deployment use PostgreSQL and a shared auth/rate-limit layer.
- A successful image build or health check does not prove that a ChatGPT plugin connection is configured. Verify the MCP handshake and tool listing after deployment.

## Deploy with Relay (relayd.run)

This repository is prepared for Relay's Docker deployment flow:

- `relay.config.json` selects the existing `Dockerfile`, container port `8080`, and readiness endpoint `/healthz`.
- `.relayignore` excludes local dependencies, build output, local data, SQLite files, and secrets from upload.
- Keep the app at one replica initially because SQLite is local persistent state and is not configured for multi-replica shared writes.
- Ensure the deployed lane preserves `/data` across container replacements. Do not assume a container writable layer is durable; verify the actual persistent-volume behavior on the target Relay server before production use.
- Add `AW_BEARER_TOKEN` using Relay's app-secret facility. Never put it in `.relay.json`, source control, or the plugin archive. Configure `AW_ALLOWED_HOSTS` only after the final hostname is known.

On the machine that has the Relay CLI and access to the Relay Agent, initialize the project for the intended lane, then run `relay doctor`, deploy to `staging`, inspect the streamed build logs, and verify `/healthz` before promoting to `prod`. The exact Relay Agent URL and credentials are environment-specific and are intentionally not embedded in this repository.

Relay is a self-hosted deployment control plane: the operator must provide the VPS/server running `relayd` and Docker. See the official [Relay quickstart](https://relayd.run/get-started) and [CLI reference](https://relayd.run/docs/cli).
