# Deployment / connection status

Current source: 0.4.0 — MCP SDK v2 migration implemented in source; not yet dependency-installed or build-verified. No cloud deployment, public HTTPS endpoint, Relay agent connection, MCP client E2E, or plugin update has been performed. Static tests pass 14/14; syntax transpilation passes, but full type-check/build remains blocked.

## Protocol implementation

- SDK packages targeted: `@modelcontextprotocol/server@2.4.0`, `@modelcontextprotocol/node@2.1.2`.
- `createMcpHandler` serves modern 2026-07-28 and legacy stateless 2025-era clients through one tool factory.
- `toNodeHandler` wraps the handler for plain Node HTTP.
- Body size bound is applied at the Node adapter and MCP handler.
- SDK package versions are pinned independently: server 2.4.0, Node adapter 2.1.2.
- All eight tools use v2 `registerTool` with explicit Zod schemas.
- Bearer auth, Origin/Host checks, SQLite WAL, `/healthz`, and graceful shutdown retained.

## Registry recovery implementation

- Added `npm run install:resilient` (`scripts/install-deps.mjs`). It checks DNS resolution before spending time on install, uses the default npm registry unless an alternate is explicitly configured, and only accepts HTTPS registries without embedded credentials.
- Optional approved fallback registries are supplied through `AW_NPM_REGISTRY_FALLBACKS` (comma-separated); no public mirror is silently trusted or selected.
- npm HTTP retry settings cover transient HTTP/network responses supported by npm; they do not repair a broken DNS resolver. If every configured registry fails DNS, the installer stops with the exact failing hosts and a remediation message.
- Added regression tests for HTTPS enforcement, explicit fallback selection, DNS failover, and fast failure.

## Current blockers

On 2026-10-31 `npm view @modelcontextprotocol/server` failed with DNS `EAI_AGAIN` resolving `registry.npmjs.org`; there are no cached v2 packages. Thus build/typecheck/runtime tests and Docker build cannot be run here. No Relay CLI or target VPS credentials are available in this environment. Registry registration remains optional and unverified.

## Deployment prerequisites

1. Restore npm registry/DNS or configure a trusted, integrity-verified mirror.
2. Run `npm install`, `npm run build`, and `npm test`; resolve all type/runtime errors.
3. Add real MCP client E2E tests for 2026-07-28 and 2025-era initialize, tools/list, identity, health, task CRUD/checkpoint.
4. Build and run Docker with persistent `/data`; verify `/healthz` and authenticated `/mcp` over HTTPS.
5. Deploy one staging replica through an authorized Relay agent/CLI and verify the actual endpoint.
6. Only after all checks pass, consider updating the existing ChatGPT plugin under the applicable Relay governance gate.

Do not paste secrets into source or chat. Do not bypass Relay STOP decisions.

## 2026-10-31 follow-up verification and provider checks

- Re-ran `npm test` against the current source tree: **15/15 PASS**.
- Render workspace access is working. Existing services and databases were inspected only; no unrelated service or database was modified.
- Render deployment is still blocked because there is no authorized Git repository containing this source and no prebuilt image registry path. The GitHub connector lists no writable repositories and exposes no repository-creation action in the available tool set.
- Replit app search was attempted as an alternate source/deploy path, but the connected tool path returned an explicit authorization denial; it was not retried.
- No Render service, paid disk, or other billable resource was created. No deployment or live MCP endpoint is claimed.
- The source ZIP is a handoff artifact only; Render cannot deploy a local ZIP directly through the connected deployment API.
