# Neura Registry — Agent Passport submission draft

Status: DRAFT — not submitted, not published, and not a Registry-issued identity.

## Agent identity

- Name: Autonomous Workbench
- Suggested slug: `autonomous-workbench`
- Product version: `0.2.0` (MCP Core source baseline)
- Summary: Orchestrates research, planning, connected-tool workflows, task continuity, and evidence-based execution across supported systems.
- Owner: **Must be selected/verified in the operator's Neura Registry Workspace.** Do not substitute an assumed person, company, or workspace.

## Capability

- Category: Agent orchestration
- Capability name: `workbench.orchestration`
- Suggested capability version: `0.2.0`
- Summary: Coordinates multi-step research and operational workflows; discovers and invokes authorized tools; maintains task state and checkpoints; records evidence and execution outcomes.

## Declared action classes

- Research and source verification
- Task planning, decomposition, and continuity
- Authorized MCP/tool discovery and invocation
- Task state updates, checkpoints, and audit events
- Engineering and business workflow coordination
- Pre-action governance handoff to Neura Relay

## Resources

- Workbench task records and checkpoints
- Connected MCP tool metadata and documented outputs
- Public source references and non-secret evidence references
- Relay Action Card / Decision Receipt / trace references

## Environments

- ChatGPT-connected tools and MCP clients
- Operator-authorized development and business workspaces
- Cloud-hosted MCP Core deployments explicitly configured by the operator

## Explicit exclusions / execution boundaries

- Registry standing is identity/context, not approval or execution authorization.
- Neura Relay reviews proposed consequential actions; it does not execute downstream work.
- Workbench Runtime remains responsible for tool execution and must enforce the operator's permissions.
- MCP Core 0.2.0 is a task-state and audit service; it does not execute arbitrary shell commands, browser actions, plugin calls, or background jobs.
- No credentials, access tokens, private payloads, personal data, or secrets belong in public Passport fields or evidence references.
- No claim of certification, owner verification, Relay readiness, or production deployment is made by this draft.

## Evidence references to attach during Registry submission

- Existing private ChatGPT plugin: `plugins_6ae565f34edc8191a9b73a31f76ef980`
- Existing plugin release: `pluginrel_6ae5668da9348191a70c8ce239000985`
- MCP Core source baseline: `autonomous-workbench-mcp-core-0.2.0`
- Relay adapter posture: `optional_adapter_not_core_dependency`

## Registry-issued values — leave blank until publication

- Agent Passport public ID / ref: **PENDING**
- Capability ref: **PENDING**
- Capability version ref: **PENDING**
- Public Passport URL: **PENDING**
- Passport JSON URL: **PENDING**
- Owner verification state: **PENDING**
- Registry standing / Relay readiness: **PENDING**

## Submission checklist

1. Sign in to the operator-owned Neura Registry Workspace.
2. Create the Agent Passport using the identity and capability details above.
3. Select/verify the real owner identity in the Workspace.
4. Publish the capability and its version; do not reuse the MCP package version as a Registry ref.
5. Copy the Registry-issued agent ref and capability-version ref.
6. Verify the public Passport and JSON projection.
7. Run `lookup_agent_passport` with those exact refs.
8. Only after readiness is confirmed, submit a new Relay Action Card for the intended integration/update. Honor any STOP or REVISE decision.
