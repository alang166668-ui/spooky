# Registry submission materials

These files are operator-side preparation materials only. They are not official Registry API payloads and do not create a Passport. Owner verification and publication must occur in the authenticated Neura Registry Workspace.

See `AGENT_PASSPORT_SUBMISSION.md` for the submission checklist and `agent-profile.draft.json` for a machine-readable worksheet.
