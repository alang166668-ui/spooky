#!/bin/sh
set -eu

# Cloud persistent volumes are commonly mounted as root. Prepare only the
# configured database directory, then drop privileges before starting Node.
DB_DIR="$(dirname "${AW_DB_PATH:-/data/workbench.sqlite}")"
mkdir -p "$DB_DIR"
chown node:node "$DB_DIR"
exec gosu node "$@"
