import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../src/index.ts', import.meta.url), 'utf8');
const pkg = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
const compose = await readFile(new URL('../compose.yaml', import.meta.url), 'utf8');
const tsconfig = JSON.parse(await readFile(new URL('../tsconfig.json', import.meta.url), 'utf8'));
const dockerfile = await readFile(new URL('../Dockerfile', import.meta.url), 'utf8');
const dockerEntrypoint = await readFile(new URL('../docker-entrypoint.sh', import.meta.url), 'utf8');
const checkpoint = await readFile(new URL('../EXECUTION_CHECKPOINT.md', import.meta.url), 'utf8');

test('package targets the split MCP SDK v2 packages', () => {
  assert.equal(pkg.version, '0.4.0');
  assert.match(source, /const VERSION = '0\.4\.0'/);
  assert.equal(pkg.dependencies['@modelcontextprotocol/server'], '2.4.0');
  assert.equal(pkg.dependencies['@modelcontextprotocol/node'], '2.1.2');
  assert.equal(pkg.dependencies['@modelcontextprotocol/sdk'], undefined);
  assert.match(pkg.dependencies['zod'], /^\^4\./);
  assert.deepEqual(tsconfig.compilerOptions.types, ['node']);
});

test('server uses v2 handler and supports modern plus legacy stateless clients', () => {
  assert.match(source, /createMcpHandler/);
  assert.match(source, /toNodeHandler/);
  assert.match(source, /legacy: 'stateless'/);
  assert.doesNotMatch(source, /StreamableHTTPServerTransport/);
  assert.doesNotMatch(source, /@modelcontextprotocol\/sdk/);
});

test('all eight MCP tools use v2 registerTool API', () => {
  assert.equal((source.match(/server\.registerTool\(/g) ?? []).length, 8);
  assert.doesNotMatch(source, /server\.tool\(/);
  assert.equal((source.match(/inputSchema: z\.object\(/g) ?? []).length, 8);
});

test('remote MCP route requires bearer authentication and JSON POST', () => {
  assert.match(source, /if \(!authorized\(req\)\)/);
  assert.match(source, /path !== '\/mcp'/);
  assert.match(source, /req\.method !== 'POST'/);
  assert.match(source, /application\\\/json\\s\*\(\?:;\|\$\)/i);
});

test('production startup refuses a missing or short bearer token', () => {
  assert.match(source, /IS_PRODUCTION && TOKEN\.length < 32/);
  assert.match(source, /AW_BEARER_TOKEN is required in production/);
});

test('database uses WAL, foreign keys, and a configurable persistent path', () => {
  assert.match(source, /AW_DB_PATH/);
  assert.match(source, /journal_mode = WAL/);
  assert.match(source, /foreign_keys = ON/);
  assert.match(compose, /workbench-data:\/data/);
});

test('request body size is bounded by both v2 Node adapter and MCP handler', () => {
  assert.match(source, /maxRequestBodySize: MAX_BODY_BYTES/);
  assert.equal((source.match(/maxRequestBodySize: MAX_BODY_BYTES/g) ?? []).length, 2);
  assert.match(source, /declaredLength > MAX_BODY_BYTES/);
});

test('container runs as non-root and has a health check', () => {
  assert.match(dockerfile, /RUN npm install\n/);
  assert.match(dockerfile, /RUN npm run build && npm prune --omit=dev/);
  assert.match(dockerfile, /USER root/);
  assert.match(dockerEntrypoint, /exec gosu node/);
  assert.match(dockerfile, /docker-entrypoint\.sh/);
  assert.match(dockerfile, /HEALTHCHECK/);
  assert.match(dockerfile, /process\.env\.PORT\|\|8080/);
  assert.match(compose, /no-new-privileges:true/);
});

test('browser Origin and optional Host allowlists are enforced', () => {
  assert.match(source, /origin && !ALLOWED_ORIGINS\.has\(origin\)/);
  assert.match(source, /ALLOWED_HOSTS\.size > 0 && !ALLOWED_HOSTS\.has\(host\)/);
});

test('identity is stable locally and Registry refs remain optional and explicitly unverified', () => {
  assert.match(source, /AW_AGENT_ID \?\? 'autonomous-workbench'/);
  assert.match(source, /AW_CAPABILITY_ID \?\? 'workbench\.orchestration'/);
  assert.match(source, /workbench_identity/);
  assert.match(source, /refs_configured_unverified/);
  assert.match(source, /verified: false/);
  assert.match(source, /Both Neura Registry refs must be configured together/);
});

test('content-type validation rejects non-JSON media types rather than substring matches', () => {
  assert.match(source, /\/\^\\s\*application\\\/json\\s\*\(\?:;\|\$\)\/i/);
});

test('graceful shutdown closes MCP handler before closing SQLite', () => {
  assert.match(source, /mcpHandler\.close\(\)\.finally/);
});

test('execution checkpoint distinguishes source migration from verified build/deployment', () => {
  assert.match(checkpoint, /v2 migration implemented, verification pending/);
  assert.match(checkpoint, /npm view` failed/);
  assert.match(checkpoint, /No Relay agent/);
});

test('resilient installer uses only explicitly configured HTTPS registries and stops on DNS failure', async () => {
  const { registryCandidates, findReachableRegistry } = await import('../scripts/install-deps.mjs');
  assert.deepEqual(registryCandidates({}), ['https://registry.npmjs.org/']);
  assert.deepEqual(registryCandidates({
    AW_NPM_REGISTRY: 'https://registry.npmjs.org',
    AW_NPM_REGISTRY_FALLBACKS: 'https://registry.npmmirror.com/,https://registry.npmjs.org/'
  }), ['https://registry.npmjs.org/', 'https://registry.npmmirror.com/']);
  assert.throws(() => registryCandidates({ AW_NPM_REGISTRY: 'http://insecure.example/' }), /HTTPS URL/);
  assert.throws(() => registryCandidates({ AW_NPM_REGISTRY: 'https://user:pass@example.com/' }), /HTTPS URL/);
  const selected = await findReachableRegistry(['https://broken.example/', 'https://reachable.example/'], async host => {
    if (host === 'broken.example') { const error = new Error('temporary DNS failure'); error.code = 'EAI_AGAIN'; throw error; }
    return [{ address: '192.0.2.1', family: 4 }];
  });
  assert.equal(selected, 'https://reachable.example/');
  await assert.rejects(() => findReachableRegistry(['https://broken.example/'], async () => {
    const error = new Error('temporary DNS failure'); error.code = 'EAI_AGAIN'; throw error;
  }), /No configured npm registry can be resolved/);
});

test('deployment manifests define persistent storage and health checks', async () => {
  const fs = await import('node:fs/promises');
  const render = await fs.readFile(new URL('../render.yaml', import.meta.url), 'utf8');
  const railway = JSON.parse(await fs.readFile(new URL('../railway.json', import.meta.url), 'utf8'));
  assert.match(render, /mountPath: \/data/);
  assert.match(render, /healthCheckPath: \/healthz/);
  assert.match(render, /sync: false/);
  assert.equal(railway.build.builder, 'DOCKERFILE');
  assert.equal(railway.deploy.healthcheckPath, '/healthz');
});
