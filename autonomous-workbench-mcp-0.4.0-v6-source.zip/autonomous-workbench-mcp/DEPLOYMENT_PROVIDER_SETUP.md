# Deployment provider setup — MCP Core 0.4.0

## Selected targets

- **Railway (preferred):** Dockerfile deployment, public HTTP endpoint, environment variables, healthcheck. Attach a persistent Volume mounted at `/data` before production use.
- **Render (fallback):** Docker web service, `/healthz` HTTP healthcheck, persistent disk mounted at `/data`. The included Blueprint uses the paid `starter` service plan because SQLite data must survive deploys/restarts; review current pricing before creating the service.

## Required runtime configuration

- `NODE_ENV=production`
- `HOST=0.0.0.0`
- `PORT` supplied by the host (the app already reads `process.env.PORT`; default 8080)
- `AW_DB_PATH=/data/workbench.sqlite`
- `AW_BEARER_TOKEN`: generate a unique random secret of at least 32 characters; enter it only in the provider's secret-variable UI.
- Optional `AW_ALLOWED_HOSTS`: exact provider hostname(s), only after assigned.
- Optional `AW_ALLOWED_ORIGINS`: configure only if the MCP client sends a browser Origin header; otherwise leave unset.

## Railway

1. Connect the repository or upload/import the source into a Railway project.
2. Create a service from the repository; it detects the root `Dockerfile` (also declared in `railway.json`).
3. Add a Volume and mount it at `/data`. Without this, SQLite is ephemeral and production data can be lost.
4. Add the variables above; set `AW_BEARER_TOKEN` as a secret. The container entrypoint fixes ownership of the mounted database directory, then drops to the unprivileged `node` user.
5. Set healthcheck path `/healthz`; expose the generated public domain.
6. Deploy, then verify `GET /healthz` and MCP `initialize`, `tools/list`, and authenticated tool calls.

## Render

1. Create a Blueprint from the repository using `render.yaml`.
2. Set the prompted `AW_BEARER_TOKEN` secret. The Blueprint provisions a 1 GB persistent disk at `/data`.
3. Review the selected paid service plan and current pricing before confirming creation.
4. Deploy, then verify `GET /healthz` and MCP `initialize`, `tools/list`, and authenticated tool calls.

## Important SQLite constraint

The service uses SQLite WAL. Run exactly one active service instance against the `/data` database volume. Do not horizontally scale this single-instance SQLite configuration. For multi-instance deployment, migrate persistence to a managed database and implement the appropriate concurrency model first.

## Current execution boundary

The current ChatGPT command environment has no Docker/Podman, no deployment CLI, and cannot resolve public DNS. Provider app connections are not yet confirmed. Therefore these manifests prepare the environment but do not create a cloud service or claim a live deployment. Do not bypass Neura Relay STOP for governed plugin actions.
