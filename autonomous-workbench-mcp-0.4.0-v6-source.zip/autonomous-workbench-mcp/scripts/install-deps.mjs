#!/usr/bin/env node
import { lookup } from 'node:dns/promises';
import { spawn } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const DEFAULT_REGISTRY = 'https://registry.npmjs.org/';

export function registryCandidates(env = process.env) {
  const values = [env.AW_NPM_REGISTRY || DEFAULT_REGISTRY,
    ...(env.AW_NPM_REGISTRY_FALLBACKS || '').split(',').map(value => value.trim()).filter(Boolean)];
  const unique = [...new Set(values.map(value => new URL(value).href))];
  for (const value of unique) {
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.username || url.password) {
      throw new Error(`Registry must be an HTTPS URL without embedded credentials: ${value}`);
    }
  }
  return unique;
}

export async function findReachableRegistry(candidates, resolveHost = lookup) {
  const failures = [];
  for (const registry of candidates) {
    const host = new URL(registry).hostname;
    try {
      await resolveHost(host);
      return registry;
    } catch (error) {
      failures.push(`${host}: ${error?.code || error?.message || 'DNS lookup failed'}`);
    }
  }
  const detail = failures.join('; ');
  throw new Error(`No configured npm registry can be resolved (${detail}). Check the execution environment DNS/network or explicitly configure AW_NPM_REGISTRY / AW_NPM_REGISTRY_FALLBACKS with an approved HTTPS registry. No untrusted mirror was selected.`);
}

export async function installDependencies({ env = process.env, resolveHost = lookup, run = spawn } = {}) {
  let candidates;
  try {
    candidates = registryCandidates(env);
  } catch (error) {
    process.stderr.write(`${error.message}\n`);
    return 2;
  }

  let registry;
  try {
    registry = await findReachableRegistry(candidates, resolveHost);
  } catch (error) {
    process.stderr.write(`${error.message}\n`);
    return 2;
  }

  process.stdout.write(`Using reachable npm registry: ${registry}\n`);
  const args = ['install', `--registry=${registry}`, '--fetch-retries=4', '--fetch-retry-factor=2',
    '--fetch-retry-mintimeout=1000', '--fetch-retry-maxtimeout=10000'];
  const child = run(process.platform === 'win32' ? 'npm.cmd' : 'npm', args, {
    stdio: 'inherit', env: { ...env, npm_config_audit: 'true', npm_config_fund: 'false' }, shell: process.platform === 'win32'
  });
  return await new Promise(resolve => {
    child.once('error', error => {
      process.stderr.write(`Could not start npm: ${error.message}\n`);
      resolve(1);
    });
    child.once('exit', (code, signal) => resolve(code ?? (signal ? 1 : 0)));
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.exitCode = await installDependencies();
}
