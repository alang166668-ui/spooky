# Tool Rate-Limit Recovery Runbook

## Scope

This runbook distinguishes an application/API HTTP 429 from a ChatGPT host-tool invocation failure such as `ChatGPTAgentToolRateLimitException`. They are not interchangeable. The latter does not expose an HTTP status, `Retry-After`, or a documented quota scope in the observed error, so do not assume API retry rules can clear it.

## Recovery policy

1. **Capture the failure**: record tool name, exact error class/message, timestamp and the operation that failed. Never record credentials or private payloads.
2. **Do not hot-loop the failed tool**: after a host-tool rate-limit exception, stop calling that same tool in the current attempt. Repeated failed calls waste capacity and may prolong throttling.
3. **Classify scope**:
   - One tool failed: test an independent execution surface once (for example, shell/container for filesystem and process work; connected app connector for its own data; web research tool for public sources).
   - Several unrelated tools fail: stop parallel retries; preserve state and report a broader platform/tooling outage as unconfirmed until independently verified.
   - HTTP 429 from an API: inspect response body and headers. Follow `Retry-After` if valid; otherwise use bounded exponential backoff with jitter.
4. **Bound API retries**: maximum 5 attempts, total retry deadline 2 minutes unless the server's valid `Retry-After` exceeds the deadline; in that case defer rather than retry early. Suggested delay: `min(30s, 1s * 2^(attempt-1)) + random(0..1s)`.
5. **Never retry non-transient errors**: authentication, permission, invalid input, exhausted credit, billing/usage cap, and policy/approval STOP require corrective action, not retries.
6. **Fallback execution**:
   - Filesystem, archive, source inspection, tests, local builds: use the independent shell/container tool when available.
   - Connected service content/actions: use that service's connector, not a shell or unrelated connector.
   - Public research: use web search/scrape; retain source URLs and dates.
   - File delivery: only link a path after verifying that exact path exists in the active runtime.
7. **Verify the fallback**: run the equivalent operation and its relevant integrity checks; report which tool performed it. A successful fallback does not mean the original tool's limit was lifted.
8. **Resume**: continue from the last verified checkpoint; do not repeat completed writes or external side effects. Use idempotency keys for external writes where supported.

## Current observed recovery in this workspace (2026-10-31)

- `python_user_visible.exec` returned `ChatGPTAgentToolRateLimitException` on two invocations. No retry-after value or public tool-specific quota documentation was exposed.
- Independent `container.exec` worked: Node v22.16.0 and npm 10.9.2 are available; the Autonomous Workbench MCP 0.4.0 source tree is present at `/mnt/data/awb-work/autonomous-workbench-mcp`.
- Docker and Podman were not found on PATH in that check. `node_modules` is absent.
- Therefore use `container.exec` for local source/archive/build/test work, and do not claim that the Python-visible tool's limit has been removed. Actual deployment still requires dependencies, a container/runtime or deployment target, and credentials as applicable.

## References

- OpenAI API rate limits: https://developers.openai.com/api/docs/guides/rate-limits
- OpenAI API rate-limit troubleshooting: https://help.openai.com/en/articles/5955604-troubleshooting-api-rate-limits-and-429-errors
- OpenAI API error codes: https://developers.openai.com/api/docs/guides/error-codes
