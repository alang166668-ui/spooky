import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { timingSafeEqual, randomUUID } from 'node:crypto';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import Database from 'better-sqlite3';
import { z } from 'zod';
import { createMcpHandler, McpServer } from '@modelcontextprotocol/server';
import { toNodeHandler } from '@modelcontextprotocol/node';

const VERSION = '0.4.0';
const AGENT_ID = process.env.AW_AGENT_ID ?? 'autonomous-workbench';
const CAPABILITY_ID = process.env.AW_CAPABILITY_ID ?? 'workbench.orchestration';
const CAPABILITY_VERSION = process.env.AW_CAPABILITY_VERSION ?? VERSION;
const REGISTRY_AGENT_REF = process.env.NEURA_REGISTRY_AGENT_REF?.trim() ?? '';
const REGISTRY_CAPABILITY_VERSION_REF = process.env.NEURA_REGISTRY_CAPABILITY_VERSION_REF?.trim() ?? '';
const registryStatus = REGISTRY_AGENT_REF && REGISTRY_CAPABILITY_VERSION_REF
  ? 'refs_configured_unverified' : 'not_configured';
if (![AGENT_ID, CAPABILITY_ID, CAPABILITY_VERSION].every(x => /^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,127}$/.test(x))) {
  throw new Error('Agent identity values must be 1-128 safe identifier characters');
}
if (Boolean(REGISTRY_AGENT_REF) !== Boolean(REGISTRY_CAPABILITY_VERSION_REF)) {
  throw new Error('Both Neura Registry refs must be configured together');
}
const PORT = Number(process.env.PORT ?? 8080);
const HOST = process.env.HOST ?? '0.0.0.0';
const DB_PATH = resolve(process.env.AW_DB_PATH ?? './data/workbench.sqlite');
const TOKEN = process.env.AW_BEARER_TOKEN ?? '';
const MAX_BODY_BYTES = Number(process.env.AW_MAX_BODY_BYTES ?? 1_048_576);
const IS_PRODUCTION = process.env.NODE_ENV === 'production';
const ALLOWED_ORIGINS = new Set((process.env.AW_ALLOWED_ORIGINS ?? '').split(',').map(x => x.trim()).filter(Boolean));
const ALLOWED_HOSTS = new Set((process.env.AW_ALLOWED_HOSTS ?? '').split(',').map(x => x.trim().toLowerCase()).filter(Boolean));

if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) throw new Error('PORT must be an integer from 1 to 65535');
if (!Number.isInteger(MAX_BODY_BYTES) || MAX_BODY_BYTES < 1024) throw new Error('AW_MAX_BODY_BYTES must be at least 1024');
if (IS_PRODUCTION && TOKEN.length < 32) throw new Error('AW_BEARER_TOKEN must be at least 32 characters in production');
if (!TOKEN && IS_PRODUCTION) throw new Error('AW_BEARER_TOKEN is required in production');

mkdirSync(dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');
db.exec(`
CREATE TABLE IF NOT EXISTS tasks (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('queued','running','blocked','completed','failed')),
 objective TEXT NOT NULL, next_step TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS checkpoints (
 id TEXT PRIMARY KEY, task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
 summary TEXT NOT NULL, state_json TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
 id TEXT PRIMARY KEY, task_id TEXT REFERENCES tasks(id) ON DELETE CASCADE,
 event_type TEXT NOT NULL, detail TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tasks_updated ON tasks(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_checkpoints_task ON checkpoints(task_id, created_at);
CREATE INDEX IF NOT EXISTS idx_events_task ON events(task_id, created_at);
`);

const now = () => new Date().toISOString();
const json = (value: unknown) => JSON.stringify(value, null, 2);
const errorResult = (message: string) => ({ isError: true, content: [{ type: 'text' as const, text: message }] });

function registerTools(server: McpServer): void {
  server.registerTool('workbench_identity', { description: 'Return the Workbench internal agent identity and optional Registry reference status. Internal IDs are not official Registry Passport refs.', inputSchema: z.object({}) }, async () => {
    return { content: [{ type: 'text', text: json({
      agent_id: AGENT_ID, capability_id: CAPABILITY_ID, capability_version: CAPABILITY_VERSION,
      identity_source: 'local_configuration', registry: { status: registryStatus,
        agent_ref_configured: Boolean(REGISTRY_AGENT_REF),
        capability_version_ref_configured: Boolean(REGISTRY_CAPABILITY_VERSION_REF),
        verified: false, note: 'Configured refs are not verified until checked against Neura Registry/Relay.' }
    }) }] };
  });

  server.registerTool('workbench_health', { description: 'Check MCP process and persistent SQLite storage.', inputSchema: z.object({}) }, async () => {
    const row = db.prepare('SELECT 1 AS ok').get() as { ok: number };
    return { content: [{ type: 'text', text: json({ status: 'ok', database: row.ok === 1 ? 'ok' : 'error', version: VERSION, time: now() }) }] };
  });

  server.registerTool('task_create', { description: 'Create a durable work item with an explicit objective.', inputSchema: z.object({
    title: z.string().trim().min(1).max(200), objective: z.string().trim().min(1).max(5000)
  }) }, async ({ title, objective }) => {
    const id = randomUUID(), ts = now();
    const tx = db.transaction(() => {
      db.prepare('INSERT INTO tasks(id,title,status,objective,created_at,updated_at) VALUES(?,?,?,?,?,?)').run(id, title, 'queued', objective, ts, ts);
      db.prepare('INSERT INTO events(id,task_id,event_type,detail,created_at) VALUES(?,?,?,?,?)').run(randomUUID(), id, 'task_created', json({ title }), ts);
    });
    tx();
    return { content: [{ type: 'text', text: json({ id, title, status: 'queued', created_at: ts }) }] };
  });

  server.registerTool('task_list', { description: 'List recent tasks, optionally filtered by status.', inputSchema: z.object({
    status: z.enum(['queued', 'running', 'blocked', 'completed', 'failed']).optional(),
    limit: z.number().int().min(1).max(100).default(25)
  }) }, async ({ status, limit }) => {
    const rows = status
      ? db.prepare('SELECT * FROM tasks WHERE status=? ORDER BY updated_at DESC LIMIT ?').all(status, limit)
      : db.prepare('SELECT * FROM tasks ORDER BY updated_at DESC LIMIT ?').all(limit);
    return { content: [{ type: 'text', text: json(rows) }] };
  });

  server.registerTool('task_get', { description: 'Read one task together with its checkpoints and event history.', inputSchema: z.object({ task_id: z.string().uuid() }) }, async ({ task_id }) => {
    const task = db.prepare('SELECT * FROM tasks WHERE id=?').get(task_id);
    if (!task) return errorResult('Task not found');
    const checkpoints = db.prepare('SELECT * FROM checkpoints WHERE task_id=? ORDER BY created_at').all(task_id) as Array<Record<string, unknown>>;
    const events = db.prepare('SELECT * FROM events WHERE task_id=? ORDER BY created_at').all(task_id);
    return { content: [{ type: 'text', text: json({ task, checkpoints: checkpoints.map(x => ({ ...x, state: JSON.parse(String(x.state_json)) })), events }) }] };
  });

  server.registerTool('task_update', { description: 'Update task status and/or its next step; records an audit event.', inputSchema: z.object({
    task_id: z.string().uuid(), status: z.enum(['queued', 'running', 'blocked', 'completed', 'failed']).optional(),
    next_step: z.string().max(5000).nullable().optional(), detail: z.string().max(5000).optional()
  }) }, async ({ task_id, status, next_step, detail }) => {
    const current = db.prepare('SELECT * FROM tasks WHERE id=?').get(task_id) as { status: string; next_step: string | null } | undefined;
    if (!current) return errorResult('Task not found');
    const newStatus = status ?? current.status;
    const newStep = next_step === undefined ? current.next_step : next_step;
    const ts = now();
    const tx = db.transaction(() => {
      db.prepare('UPDATE tasks SET status=?,next_step=?,updated_at=? WHERE id=?').run(newStatus, newStep, ts, task_id);
      db.prepare('INSERT INTO events(id,task_id,event_type,detail,created_at) VALUES(?,?,?,?,?)').run(randomUUID(), task_id, 'task_updated', json({ status: newStatus, next_step: newStep, detail: detail ?? null }), ts);
    });
    tx();
    return { content: [{ type: 'text', text: json({ task_id, status: newStatus, next_step: newStep, updated_at: ts }) }] };
  });

  server.registerTool('task_checkpoint', { description: 'Persist a resumable checkpoint: progress summary, structured state, and next step.', inputSchema: z.object({
    task_id: z.string().uuid(), summary: z.string().trim().min(1).max(5000),
    state: z.record(z.string(), z.unknown()).default({}), next_step: z.string().max(5000).optional()
  }) }, async ({ task_id, summary, state, next_step }) => {
    if (!db.prepare('SELECT id FROM tasks WHERE id=?').get(task_id)) return errorResult('Task not found');
    const id = randomUUID(), ts = now();
    const tx = db.transaction(() => {
      db.prepare('INSERT INTO checkpoints(id,task_id,summary,state_json,created_at) VALUES(?,?,?,?,?)').run(id, task_id, summary, json(state), ts);
      db.prepare('UPDATE tasks SET next_step=COALESCE(?,next_step),updated_at=? WHERE id=?').run(next_step ?? null, ts, task_id);
      db.prepare('INSERT INTO events(id,task_id,event_type,detail,created_at) VALUES(?,?,?,?,?)').run(randomUUID(), task_id, 'checkpoint_saved', json({ checkpoint_id: id, summary, next_step: next_step ?? null }), ts);
    });
    tx();
    return { content: [{ type: 'text', text: json({ checkpoint_id: id, task_id, created_at: ts }) }] };
  });

  server.registerTool('task_event', { description: 'Append an auditable event to a task without changing its status.', inputSchema: z.object({
    task_id: z.string().uuid(), event_type: z.string().trim().min(1).max(100), detail: z.string().min(1).max(10000)
  }) }, async ({ task_id, event_type, detail }) => {
    if (!db.prepare('SELECT id FROM tasks WHERE id=?').get(task_id)) return errorResult('Task not found');
    const id = randomUUID(), ts = now();
    db.prepare('INSERT INTO events(id,task_id,event_type,detail,created_at) VALUES(?,?,?,?,?)').run(id, task_id, event_type, detail, ts);
    return { content: [{ type: 'text', text: json({ event_id: id, task_id, created_at: ts }) }] };
  });
}

function authorized(req: IncomingMessage): boolean {
  if (!TOKEN) return !IS_PRODUCTION; // convenient local development only
  const header = req.headers.authorization ?? '';
  const match = /^Bearer ([^\s]+)$/.exec(header);
  if (!match) return false;
  const supplied = Buffer.from(match[1]);
  const expected = Buffer.from(TOKEN);
  return supplied.length === expected.length && timingSafeEqual(supplied, expected);
}

function send(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
  res.end(JSON.stringify(body));
}

const mcpHandler = createMcpHandler(() => {
  const server = new McpServer(
    { name: 'autonomous-workbench-core', version: VERSION },
    { capabilities: { tools: {} } }
  );
  registerTools(server);
  return server;
}, {
  // One factory serves modern 2026-07-28 requests and stateless 2025-era clients.
  legacy: 'stateless',
  maxRequestBodySize: MAX_BODY_BYTES,
  onerror: (error) => process.stderr.write(`MCP handler error: ${error.message}\n`)
});
const nodeMcpHandler = toNodeHandler(mcpHandler, {
  maxRequestBodySize: MAX_BODY_BYTES,
  onerror: (error) => process.stderr.write(`MCP Node adapter error: ${error.message}\n`)
});

const httpServer = createServer(async (req, res) => {
  const path = new URL(req.url ?? '/', 'http://localhost').pathname;
  if (path === '/healthz' && req.method === 'GET') {
    try {
      db.prepare('SELECT 1').get();
      send(res, 200, {
        status: 'ok', service: 'autonomous-workbench-core', version: VERSION,
        agent_id: AGENT_ID, capability_id: CAPABILITY_ID, capability_version: CAPABILITY_VERSION,
        registry_status: registryStatus
      });
    } catch { send(res, 503, { status: 'error' }); }
    return;
  }
  if (path !== '/mcp') { send(res, 404, { error: 'not_found' }); return; }
  const origin = req.headers.origin;
  if (origin && !ALLOWED_ORIGINS.has(origin)) { send(res, 403, { error: 'origin_not_allowed' }); return; }
  const host = (req.headers.host ?? '').toLowerCase();
  if (ALLOWED_HOSTS.size > 0 && !ALLOWED_HOSTS.has(host)) { send(res, 403, { error: 'host_not_allowed' }); return; }
  if (!authorized(req)) { send(res, 401, { error: 'unauthorized' }); return; }
  if (req.method !== 'POST') { res.setHeader('allow', 'POST'); send(res, 405, { error: 'method_not_allowed' }); return; }
  const contentType = req.headers['content-type'] ?? '';
  if (!/^\s*application\/json\s*(?:;|$)/i.test(contentType)) { send(res, 415, { error: 'content_type_must_be_application_json' }); return; }
  const declaredLength = Number(req.headers['content-length'] ?? 0);
  if (declaredLength > MAX_BODY_BYTES) { send(res, 413, { error: 'request_too_large' }); return; }
  try {
    await nodeMcpHandler(req, res);
  } catch (error) {
    if (!res.headersSent) send(res, 500, { error: 'mcp_request_failed' });
    process.stderr.write(`MCP request failed: ${error instanceof Error ? error.message : 'unknown error'}\n`);
  }
});
httpServer.requestTimeout = 30_000;
httpServer.headersTimeout = 35_000;
httpServer.keepAliveTimeout = 5_000;
httpServer.listen(PORT, HOST, () => process.stdout.write(`Autonomous Workbench MCP ${VERSION} listening on ${HOST}:${PORT}\n`));

async function shutdown(signal: string): Promise<void> {
  process.stderr.write(`Received ${signal}; shutting down\n`);
  httpServer.close(() => { void mcpHandler.close().finally(() => { db.close(); process.exit(0); }); });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => void shutdown('SIGTERM'));
process.on('SIGINT', () => void shutdown('SIGINT'));
